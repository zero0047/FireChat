package com.example.firechat.FriendRequests;

public class FriendRequestModel {
    private  String Username;
    private  String UserId;
    private  String PhotoName;

    public FriendRequestModel(String username, String userId, String photoName) {
        Username = username;
        UserId = userId;
        PhotoName = photoName;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public String getPhotoName() {
        return PhotoName;
    }

    public void setPhotoName(String photoName) {
        PhotoName = photoName;
    }
}
