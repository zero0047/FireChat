package com.example.firechat.Profile;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.example.firechat.login.LoginActivity;
import com.example.firechat.password.ChangePasswordActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

import static android.view.View.GONE;

public class ProfileActivity extends AppCompatActivity {

    private TextInputEditText etEmail , etName;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private Uri localFileUri , ServerFileUri;
    private ImageView ivProfile;
    private StorageReference mStorageRef;
    private View progressBar;


    public void logOut(View view)
    {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(ProfileActivity.this,LoginActivity.class));
        finish();
    }


    public void chooseImage(View view)
    {
        if(ServerFileUri==null)
        {
            selectImage();
        }else
        {
            PopupMenu popupMenu = new PopupMenu(this,view);
            popupMenu.getMenuInflater().inflate(R.menu.menu_profile,popupMenu.getMenu());
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    int id = item.getItemId();
                    if(id == R.id.selectPhoto)
                    {
                        selectImage();
                    }else if(id == R.id.deletePhoto)
                    {
                        removePhoto();
                    }


                    return false;
                }
            });
            popupMenu.show();
        }
    }

    public void save(View view)
    {
        if(etName.getText().toString().trim().equals(""))
        {
            etName.setError("Enter your Name");
        }
        else {
            progressBar.setVisibility(View.VISIBLE);
            if (localFileUri != null) {
                updateNameAndPhoto();
            } else {
                updateOnlyName();
            }
            progressBar.setVisibility(GONE);
        }
    }


    private void selectImage()
    {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 101);
        }else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},102);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 102)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 101);
            }else
            {
                Toast.makeText(this, R.string.access_permission_required, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101)
        {
            if(resultCode == RESULT_OK)
            {
                localFileUri = data.getData();
                ivProfile.setImageURI(localFileUri);

            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorAccent));

        if(getSupportActionBar()!=null)
            getSupportActionBar().hide();



        etEmail = findViewById(R.id.etEmail);
        etName = findViewById(R.id.etName);
        ivProfile = findViewById(R.id.profileImageView);
        progressBar = findViewById(R.id.progressBar);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        user = FirebaseAuth.getInstance().getCurrentUser();

        if(user!=null)
        {
            etName.setText(user.getDisplayName());
            etEmail.setText(user.getEmail());
            ServerFileUri = user.getPhotoUrl();
            if(ServerFileUri!=null)
            {
                Glide.with(this)
                        .load(ServerFileUri)
                        .placeholder(R.drawable.default__better)
                        .error(R.drawable.default__better)
                        .into(ivProfile);
            }
        }
    }
    private void updateNameAndPhoto()
    {
        String strFileName = user.getUid() + ".jpg";
        final StorageReference fileStr = mStorageRef.child("images/" + strFileName);
        progressBar.setVisibility(View.VISIBLE);
        fileStr.putFile(localFileUri)
                .addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        progressBar.setVisibility(GONE);
                        if(task.isSuccessful())
                        {
                            fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    ServerFileUri = uri;
                                    UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                                            .setDisplayName(etName.getText().toString().trim())
                                            .setPhotoUri(ServerFileUri)
                                            .build();
                                    user.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                String userID  = user.getUid();
                                                databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
                                                HashMap<String , String> hashMap = new HashMap<>();
                                                hashMap.put(NodeNames.NAME,etName.getText().toString().trim());
                                                hashMap.put(NodeNames.PHOTO,ServerFileUri.getPath());
                                                hashMap.put(NodeNames.EMAIL,etEmail.getText().toString().trim());
                                                hashMap.put(NodeNames.ONLINE,"true");
                                                progressBar.setVisibility(View.VISIBLE);
                                                databaseReference.child(userID).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        progressBar.setVisibility(GONE);
                                                        if(task.isSuccessful())
                                                        {
                                                            Toast.makeText(ProfileActivity.this, "Profile Updated!", Toast.LENGTH_SHORT).show();
//                                                           // startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
                                                            finish();
                                                        }else
                                                        {
                                                            Toast.makeText(ProfileActivity.this, "Something went wrong: "+task.getException(), Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                            }else
                                            {
                                                Toast.makeText(ProfileActivity.this,"Something went wrong: "+task.getException(), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                });
    }

    private void updateOnlyName()
    {   progressBar.setVisibility(View.VISIBLE);
        UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                .setDisplayName(etName.getText().toString().trim())
                .build();

        user.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressBar.setVisibility(GONE);
                if(task.isSuccessful())
                {
                    String userID  = user.getUid();
                    databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
                    HashMap<String , String> hashMap = new HashMap<>();
                    hashMap.put(NodeNames.NAME,etName.getText().toString().trim());
                    hashMap.put(NodeNames.EMAIL,etEmail.getText().toString().trim());
                    hashMap.put(NodeNames.PHOTO,ServerFileUri.getPath());
                    hashMap.put(NodeNames.ONLINE,"true");

                    progressBar.setVisibility(View.VISIBLE);
                    databaseReference.child(userID).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            progressBar.setVisibility(GONE);
                            if(task.isSuccessful())
                            {
                                Toast.makeText(ProfileActivity.this, "Profile Updated!", Toast.LENGTH_SHORT).show();
//                                startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
                                finish();
                            }else
                            {
                                Toast.makeText(ProfileActivity.this, "Something went wrong: "+task.getException(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else
                {
                    Toast.makeText(ProfileActivity.this,"Something went wrong: "+task.getException(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void removePhoto()
    {      progressBar.setVisibility(View.VISIBLE);
        UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                .setDisplayName(etName.getText().toString().trim())
                .setPhotoUri(null)
                .build();
        user.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressBar.setVisibility(GONE);
                if(task.isSuccessful())
                {
                    String userID  = user.getUid();
                    databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
                    StorageReference storageReference = FirebaseStorage.getInstance().getReference()
                            .child(Constants.PROFILE_FOLDER+"/"+user.getUid()+".jpg");
                    storageReference.delete();
                    HashMap<String , String> hashMap = new HashMap<>();

                    hashMap.put(NodeNames.NAME,etName.getText().toString().trim());
                    hashMap.put(NodeNames.EMAIL,etEmail.getText().toString().trim());
                    hashMap.put(NodeNames.PHOTO,"removed");
                    hashMap.put(NodeNames.ONLINE,"true");
                    progressBar.setVisibility(View.VISIBLE);
                    databaseReference.child(userID).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            progressBar.setVisibility(GONE);
                            if(task.isSuccessful())
                            {
                                Toast.makeText(ProfileActivity.this, R.string.profile_deleted, Toast.LENGTH_SHORT).show();
//                                startActivity(new Intent(ProfileActivity.this, LoginActivity.class));
                                finish();
                            }else
                            {
                                Toast.makeText(ProfileActivity.this, "Something went wrong: "+task.getException(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else
                {
                    Toast.makeText(ProfileActivity.this,"Something went wrong: "+task.getException() , Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void changePassword(View view)
    {
        startActivity(new Intent(ProfileActivity.this, ChangePasswordActivity.class));
    }
}