package com.example.firechat.password;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.firechat.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {

    TextInputEditText etOldPass , etNewPass , etConfirmPass;
    String oldPass,newPass,newConfirmPass;
    private View progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        etOldPass = findViewById(R.id.etOldPassword);
        etNewPass = findViewById(R.id.etNewPassword);
        etConfirmPass = findViewById(R.id.etConfirmNewPassword);
        progressBar = findViewById(R.id.progressBar);


        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorAccent));

        if(getSupportActionBar()!=null)
            getSupportActionBar().hide();

    }

    public void changePassword(View view)
    {
        oldPass = etOldPass.getText().toString().trim();
        newPass = etNewPass.getText().toString().trim();
        newConfirmPass = etConfirmPass.getText().toString().trim();

        if(oldPass.equals(""))
        {
            etOldPass.setError("Enter old Password");
        }else if(newPass.equals(""))
        {
            etNewPass.setError("Enter new Password");
        }else if(newConfirmPass.equals(""))
        {
            etConfirmPass.setError("Enter confirm Password");
        }else if(!newPass.equals(newConfirmPass))
        {
            etConfirmPass.setError("Password doesn't match new Password");
        }else
        {
            updatePassword();
        }
    }

    private void updatePassword() {
        progressBar.setVisibility(View.VISIBLE);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        final FirebaseUser user = auth.getCurrentUser();

        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(),oldPass);
        user.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressBar.setVisibility(View.GONE);
                        if(task.isSuccessful())
                        {
                            user.updatePassword(newPass)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(ChangePasswordActivity.this, "Password Updated!", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }else{
                                        Toast.makeText(ChangePasswordActivity.this, "Something went wrong: "+
                                                task.getException(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }else{
                            Toast.makeText(ChangePasswordActivity.this, "Incorrect old Password: "+
                                    task.getException(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}