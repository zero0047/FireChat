package com.example.firechat.Comman;

public class NodeNames {
    public static final String USERS = "Users";
    public static final String MESSAGES = "Messages";
    public static final String FRIEND_REQUEST = "friend_request" ;
    public static final String CHATS ="chats" ;


    public static final String NAME = "Name";
    public static final String EMAIL = "email";
    public static final String ONLINE = "online";
    public static final String PHOTO = "photo";

    public static final String FRIEND_REQUEST_TYPE ="friend_request_type" ;

    public static final String TIME_STAMP ="time_stamp" ;
    public static final String MESSAGE = "message";
    public static final String MESSAGE_TYPE = "message_Type";
    public static final String MESSAGE_ID = "messageId";
    public static final String MESSAGE_FROM = "messageFrom";
    public static final String MESSAGE_TIME = "messageTime";

}
