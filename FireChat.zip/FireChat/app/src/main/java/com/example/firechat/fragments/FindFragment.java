package com.example.firechat.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.FindFriends.FindFriends;
import com.example.firechat.FindFriends.FindFriendsAdapter;
import com.example.firechat.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class FindFragment extends Fragment {

    private RecyclerView rvFind;
    private FindFriendsAdapter findFriendsAdapter;
    private List<FindFriends> findFriendsList;
    private TextView tvEmptyList;
    private EditText etSearch;
    private SwipeRefreshLayout srlUsers;

    private View progressBar;
    private DatabaseReference databaseReference , friendsDatabaseReference;
    private FirebaseUser currentUser;
    public FindFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_find, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvFind = view.findViewById(R.id.rvFind);
        progressBar = view.findViewById(R.id.progressBar);
        tvEmptyList = view.findViewById(R.id.tvEmptyList);
//        etSearch = view.findViewById(R.id.etSearch);
        srlUsers = view.findViewById(R.id.srlUsers);

        rvFind.setLayoutManager(new LinearLayoutManager(getActivity()));

        findFriendsList = new ArrayList<>();
        findFriendsAdapter = new FindFriendsAdapter(getActivity(),findFriendsList);

        rvFind.setAdapter(findFriendsAdapter);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();


        databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
        friendsDatabaseReference = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.FRIEND_REQUEST).child(currentUser.getUid());

        progressBar.setVisibility(View.VISIBLE);
        tvEmptyList.setVisibility(View.VISIBLE);

        loadList();

        srlUsers.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                loadList();
            }
        });



    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        int id = item.getItemId();
//        if (id == R.id.navigation_action_search) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    @Override
//    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//
//        inflater.inflate(R.menu.menu_main, menu);
//        MenuItem searchMenuItem = menu.findItem(R.id.navigation_action_search);
//
//
//
//
//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchMenuItem);
//
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//
//                return true;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String searchQuery) {
//                filter(searchQuery.trim());
//                return true;
//            }
//        });
//
//        MenuItemCompat.setOnActionExpandListener(searchMenuItem, new MenuItemCompat.OnActionExpandListener() {
//            @Override
//            public boolean onMenuItemActionCollapse(MenuItem item) {
//                // Do something when collapsed
//                return true;  // Return true to collapse action view
//            }
//
//            @Override
//            public boolean onMenuItemActionExpand(MenuItem item) {
//                // Do something when expanded
//                return true;  // Return true to expand action view
//            }
//        });
//    }


    private void loadList()
    {
        Query query = databaseReference.orderByChild(NodeNames.NAME);
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(findFriendsList!=null)
                    findFriendsList.clear();
                findFriendsAdapter.notifyDataSetChanged();
                tvEmptyList.setVisibility(View.VISIBLE);
                for(DataSnapshot dataSnapshot : snapshot.getChildren())
                {
                    final String userId = dataSnapshot.getKey();
                    if(userId.equals(currentUser.getUid()))
                    {
                        Log.e("SAME","SAME USER ID");
                        continue;
                    }
//


                    if(dataSnapshot.child(NodeNames.NAME).getValue()!=null)
                    {
                        Log.e("REACHED","SUCCESS");
                        final String fullName = dataSnapshot.child(NodeNames.NAME).getValue().toString();
                        final String Photo = dataSnapshot.child(NodeNames.PHOTO).getValue().toString();

                        friendsDatabaseReference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(snapshot.exists())
                                {
                                    String requestType = snapshot.child(NodeNames.FRIEND_REQUEST_TYPE).getValue().toString();
                                    if(requestType.equals(Constants.REQUEST_SENT))
                                    {
                                        findFriendsList.add(new FindFriends(fullName,Photo,userId,true));
                                        findFriendsAdapter.notifyDataSetChanged();
                                        srlUsers.setRefreshing(false);
                                    }
                                }else
                                {
                                    findFriendsList.add(new FindFriends(fullName,Photo,userId,false));
                                    findFriendsAdapter.notifyDataSetChanged();
                                    srlUsers.setRefreshing(false);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                tvEmptyList.setVisibility(View.GONE);
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(getContext(), "Something went wrong: "
                                        +error.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });


                        tvEmptyList.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);

                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), "Something went wrong: "
                        +error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void filter(String text) {
        ArrayList<FindFriends> filteredList = new ArrayList<>();
        filteredList.clear();

        for (FindFriends item : findFriendsList)
        {
            if (item.getUsername().toLowerCase().contains(text.toLowerCase()))
            {
                filteredList.add(item);
            }else if(text.equals(""))
            {
                filteredList.clear();
            }
        }

        findFriendsAdapter.filterList(filteredList);
    }
}