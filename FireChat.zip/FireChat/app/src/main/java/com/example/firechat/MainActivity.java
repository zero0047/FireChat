package com.example.firechat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.example.firechat.Profile.ProfileActivity;
import com.example.firechat.fragments.ChatFragment;
import com.example.firechat.fragments.FindFragment;
import com.example.firechat.fragments.RequestFragment;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    TabLayout tabMain;
    ViewPager vpMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabMain = findViewById(R.id.tabMain);
        vpMain = findViewById(R.id.vpMain);


        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorPrimary));

        setVpMain();


    }

    class Adapter extends FragmentPagerAdapter{

        public Adapter(@NonNull FragmentManager fm, int behavior) {
            super(fm, behavior);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            switch (position)
            {
                case 0:
                    ChatFragment chatFragment = new ChatFragment();
                    return chatFragment;
                case 1:
                    RequestFragment requestFragment = new RequestFragment();
                    return requestFragment;
                case 2:
                    FindFragment findFragment = new FindFragment();
                    return findFragment;
            }
            return null;
        }

        @Override
        public int getCount() {
            return tabMain.getTabCount();
        }
    }

    private void setVpMain()
    {
        tabMain.addTab(tabMain.newTab().setCustomView(R.layout.tab_chat));
        tabMain.addTab(tabMain.newTab().setCustomView(R.layout.tab_requests));
        tabMain.addTab(tabMain.newTab().setCustomView(R.layout.tab_find));

        tabMain.setTabGravity(TabLayout.GRAVITY_FILL);

        Adapter adapter = new Adapter(getSupportFragmentManager() ,
                FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        vpMain.setAdapter(adapter);
        tabMain.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vpMain.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        vpMain.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabMain));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);




        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menu_Profile)
        {
            startActivity(new Intent(MainActivity.this, ProfileActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean onBackPressed = false;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if(tabMain.getSelectedTabPosition()>0)
            tabMain.selectTab(tabMain.getTabAt(0));
        else{
            if(onBackPressed)
            {
                finishAffinity();
            }
            else
            {
                onBackPressed = true;
                Toast.makeText(this, R.string.on_back_pressed, Toast.LENGTH_SHORT).show();
                android.os.Handler handler = new android.os.Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        onBackPressed = false;
                    }
                },2000);
            }
        }
    }
}
