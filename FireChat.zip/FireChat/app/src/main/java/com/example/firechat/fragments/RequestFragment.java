package com.example.firechat.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.FriendRequests.FriendRequestAdapter;
import com.example.firechat.FriendRequests.FriendRequestModel;
import com.example.firechat.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class RequestFragment extends Fragment {

    private RecyclerView rvRequests;
    private TextView tvEmptyList;
    private List<FriendRequestModel> friendRequestModelList;
    private FriendRequestAdapter adapter;
    private SwipeRefreshLayout srlRequests;

    private DatabaseReference databaseReferenceRequests,databaseReferenceUsers;
    private FirebaseUser currentUser;
    private View progressBar;
    private EditText etSearch;



    public RequestFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_request, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvRequests = view.findViewById(R.id.rvRequests);
        tvEmptyList = view.findViewById(R.id.tvRequestsAppear);
        progressBar = view.findViewById(R.id.progressBar);
//        etSearch = view.findViewById(R.id.etSearch);
//        srlRequests = view.findViewById(R.id.srlRequests);

        rvRequests.setLayoutManager(new LinearLayoutManager(getActivity()));
        friendRequestModelList = new ArrayList<>();
        adapter = new FriendRequestAdapter(getActivity(),friendRequestModelList);
        rvRequests.setAdapter(adapter);

        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        databaseReferenceUsers = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.USERS);
        databaseReferenceRequests = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.FRIEND_REQUEST).child(currentUser.getUid());
        tvEmptyList.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);

        load();
//        srlRequests.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                load();
//            }
//        });
//        etSearch.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//                if (!editable.toString().trim().matches(""))
//                {
//                    filter(editable.toString());
//                }
//
//            }
//        });
    }
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        int id = item.getItemId();
//        if (id == R.id.navigation_action_search) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    @Override
//    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
//
//        inflater.inflate(R.menu.menu_main, menu);
//        MenuItem searchMenuItem = menu.findItem(R.id.navigation_action_search);
//
//
//
//
//        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchMenuItem);
//
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//
//                return true;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String searchQuery) {
//                filter(searchQuery.trim());
//                return true;
//            }
//        });
//
//        MenuItemCompat.setOnActionExpandListener(searchMenuItem, new MenuItemCompat.OnActionExpandListener() {
//            @Override
//            public boolean onMenuItemActionCollapse(MenuItem item) {
//                // Do something when collapsed
//                return true;  // Return true to collapse action view
//            }
//
//            @Override
//            public boolean onMenuItemActionExpand(MenuItem item) {
//                // Do something when expanded
//                return true;  // Return true to expand action view
//            }
//        });
//    }



    private void load()
    {
        databaseReferenceRequests.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressBar.setVisibility(View.GONE);
                if(friendRequestModelList!=null)
                {
                    friendRequestModelList.clear();
                }
                adapter.notifyDataSetChanged();
                tvEmptyList.setVisibility(View.VISIBLE);


                for(DataSnapshot ds: snapshot.getChildren())
                {
                    if(ds.exists())
                    {
                        String requestType = ds.child(NodeNames.FRIEND_REQUEST_TYPE).getValue()
                                .toString();
                        if(requestType.equals(Constants.REQUEST_RECEIVED))
                        {
                            final String userId = ds.getKey();
                            databaseReferenceUsers.child(userId).addListenerForSingleValueEvent(
                                    new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                            String userName = snapshot.child(NodeNames.NAME).getValue().toString();
                                            String photoName = "";
                                            if(snapshot.child(NodeNames.PHOTO).getValue()!="removed")
                                            {
                                                photoName = snapshot.child(NodeNames.PHOTO).getValue().toString();
                                            }
                                            FriendRequestModel friendRequestModel = new FriendRequestModel(userName,userId,photoName);
                                            friendRequestModelList.add(friendRequestModel);
                                            Log.e("RequestCount",String.valueOf(friendRequestModelList.size()));
                                            adapter.notifyDataSetChanged();
                                            tvEmptyList.setVisibility(View.GONE);
//                                            srlRequests.setRefreshing(false);

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            Toast.makeText(getActivity(),
                                                    getActivity().getString(R.string.friend_request_fetch_failed,error.getMessage())
                                                    , Toast.LENGTH_SHORT).show();
                                            progressBar.setVisibility(View.GONE);
//                                            srlRequests.setRefreshing(false);
                                        }
                                    }
                            );
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getActivity(),
                        getActivity().getString(R.string.friend_request_fetch_failed,error.getMessage())
                        , Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
//                srlRequests.setRefreshing(false);
            }
        });
    }

    private void filter(String text) {
        if(text.equals(""))
        {

        }
        ArrayList<FriendRequestModel> filteredList = new ArrayList<>();

        for (FriendRequestModel item : friendRequestModelList)
        {
            if (item.getUsername().toLowerCase().contains(text.toLowerCase()))
            {
                filteredList.add(item);
            }
        }

        adapter.filterList(filteredList);
    }
}