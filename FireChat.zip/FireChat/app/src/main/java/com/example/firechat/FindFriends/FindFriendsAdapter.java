package com.example.firechat.FindFriends;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FindFriendsAdapter extends RecyclerView.Adapter<FindFriendsAdapter.FindFriendsViewHolder> {

    Context context;
    static List<FindFriends> findFriendsList;
    DatabaseReference friendRequest;
    FirebaseUser currentUser;
    String userID;

    public FindFriendsAdapter(Context context, List<FindFriends> findFriendsList) {
        this.context = context;
        this.findFriendsList = findFriendsList;
    }




    @NonNull
    @Override
    public FindFriendsAdapter.FindFriendsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.find_friends_layout,parent,false);
        return new FindFriendsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FindFriendsAdapter.FindFriendsViewHolder holder, int position) {
        final FindFriends findFriends = findFriendsList.get(position);
        holder.tvUserName.setText(findFriends.getUsername());
       // Uri uri = Uri.parse(Constants.IMAGES_FOLDER+"/"+findFriends.getPhotoId());
        Log.e("PHOTO ID",findFriends.getPhotoId());
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        StorageReference fileRef = FirebaseStorage.getInstance().getReference()
                .child(Constants.PROFILE_FOLDER+"/"+findFriends.getUserId()+".jpg");
        fileRef.getDownloadUrl()
        .addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Log.e("URI",uri.toString());
                Glide.with(context)
                        .load(uri)
                        .placeholder(R.drawable.default__better)
                        .error(R.drawable.default__better)
                        .into(holder.ivProfile);
            }
        });

        friendRequest = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.FRIEND_REQUEST);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if(findFriends.getRequestSent())
        {
            holder.btn_SendRequest.setVisibility(View.GONE);
            holder.btn_CancelRequest.setVisibility(View.VISIBLE);
        }
        else
        {
            holder.btn_SendRequest.setVisibility(View.VISIBLE);
            holder.btn_CancelRequest.setVisibility(View.GONE);
        }

        holder.btn_SendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.btn_SendRequest.setEnabled(false);
                holder.pbRequest.setVisibility(View.VISIBLE);
                userID = findFriends.getUserId();
                friendRequest.child(currentUser.getUid()).child(userID)
                        .child(NodeNames.FRIEND_REQUEST_TYPE)
                        .setValue(Constants.REQUEST_SENT).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            holder.btn_SendRequest.setEnabled(true);
                            friendRequest.child(userID).child(currentUser.getUid())
                                    .child(NodeNames.FRIEND_REQUEST_TYPE)
                                    .setValue(Constants.REQUEST_RECEIVED).addOnCompleteListener(
                                    new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                Toast.makeText(context, R.string.request_sent_success, Toast.LENGTH_SHORT).show();
                                                holder.pbRequest.setVisibility(View.GONE);
                                                holder.btn_SendRequest.setVisibility(View.GONE);
                                                holder.btn_CancelRequest.setVisibility(View.VISIBLE);
                                            }
                                            else
                                            {
                                                Toast.makeText(context,
                                                        context.getString(R.string.request_failed,task.getException()),
                                                        Toast.LENGTH_SHORT).show();
                                                holder.pbRequest.setVisibility(View.GONE);
                                                holder.btn_SendRequest.setVisibility(View.VISIBLE);
                                                holder.btn_CancelRequest.setVisibility(View.GONE);
                                            }
                                        }
                                    }
                            );

                        }else
                        {
                            holder.btn_SendRequest.setEnabled(true);
                            Toast.makeText(context,
                                    context.getString(R.string.request_failed,task.getException()),
                                    Toast.LENGTH_SHORT).show();
                            holder.pbRequest.setVisibility(View.GONE);
                            holder.btn_SendRequest.setVisibility(View.VISIBLE);
                            holder.btn_CancelRequest.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });

        holder.btn_CancelRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.btn_CancelRequest.setEnabled(false);
                holder.pbRequest.setVisibility(View.VISIBLE);
                userID = findFriends.getUserId();
                friendRequest.child(currentUser.getUid()).child(userID)
                        .child(NodeNames.FRIEND_REQUEST_TYPE)
                        .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            holder.btn_CancelRequest.setEnabled(true);
                            friendRequest.child(userID).child(currentUser.getUid())
                                    .child(NodeNames.FRIEND_REQUEST_TYPE)
                                    .removeValue().addOnCompleteListener(
                                    new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                Toast.makeText(context, R.string.request_cancelled_success, Toast.LENGTH_SHORT).show();
                                                holder.pbRequest.setVisibility(View.GONE);
                                                holder.btn_SendRequest.setVisibility(View.VISIBLE);
                                                holder.btn_CancelRequest.setVisibility(View.GONE);
                                            }
                                            else
                                            {
                                                Toast.makeText(context,
                                                        context.getString(R.string.request_cancel_failed,task.getException()),
                                                        Toast.LENGTH_SHORT).show();
                                                holder.pbRequest.setVisibility(View.GONE);
                                                holder.btn_SendRequest.setVisibility(View.GONE);
                                                holder.btn_CancelRequest.setVisibility(View.VISIBLE);
                                            }
                                        }
                                    }
                            );

                        }else
                        {
                            holder.btn_CancelRequest.setEnabled(true);
                            Toast.makeText(context,
                                    context.getString(R.string.request_cancel_failed,task.getException()),
                                    Toast.LENGTH_SHORT).show();
                            holder.pbRequest.setVisibility(View.GONE);
                            holder.btn_SendRequest.setVisibility(View.GONE);
                            holder.btn_CancelRequest.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });

    }

    @Override
    public int getItemCount() {
        Log.e("SIZE",String.valueOf(findFriendsList.size()));
        return findFriendsList.size();
    }
    public void  filterList(ArrayList<FindFriends> filteredList)
    {

        findFriendsList = filteredList;
        notifyDataSetChanged();


    }
    @Override public int getItemViewType(int position) {        return position;}

    public class FindFriendsViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivProfile;
        private TextView tvUserName;
        private Button btn_SendRequest , btn_CancelRequest;
        private ProgressBar pbRequest;

        public FindFriendsViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProfile = itemView.findViewById(R.id.profileImageView);
            tvUserName = itemView.findViewById(R.id.userNameFull);
            btn_SendRequest = itemView.findViewById(R.id.btnSendRequest);
            btn_CancelRequest = itemView.findViewById(R.id.btnCancelRequest);
            pbRequest = itemView.findViewById(R.id.pbRequest);

        }
    }
}
