package com.example.firechat.Chats;

public class MessageModel {
    private String message;
    private String messageFrom;
    private String messageId;
    private long messageTime;
    private String message_Type;

    public MessageModel() {
    }

    public MessageModel(String message, String messageFrom, String messageId, long messageTime, String message_Type) {
        this.message = message;
        this.messageFrom = messageFrom;
        this.messageId = messageId;
        this.messageTime = messageTime;
        this.message_Type = message_Type;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessageFrom() {
        return messageFrom;
    }

    public void setMessageFrom(String messageFrom) {
        this.messageFrom = messageFrom;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public long getMessageTime() {
        return messageTime;
    }

    public void setMessageTime(long messageTime) {
        this.messageTime = messageTime;
    }

    public String getMessage_Type() {
        return message_Type;
    }

    public void setMessage_Type(String message_Type) {
        this.message_Type = message_Type;
    }
}
