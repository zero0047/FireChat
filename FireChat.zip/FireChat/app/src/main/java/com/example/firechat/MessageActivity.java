package com.example.firechat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.firechat.Comman.Util;

public class MessageActivity extends AppCompatActivity {
    ProgressBar internetCheckBar;
    TextView tvInternetCheck;
    Button btnClose , btnRetry;
    private ConnectivityManager.NetworkCallback callback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        internetCheckBar = findViewById(R.id.internetCheckBar);
        tvInternetCheck = findViewById(R.id.tvInternetCheck);
        btnClose = findViewById(R.id.btnClose);
        btnRetry = findViewById(R.id.btnRetry);
        internetCheckBar.setVisibility(View.GONE);

        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorPrimary));

        if(getSupportActionBar()!=null)
            getSupportActionBar().hide();

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP)
        {
            internetCheckBar.setVisibility(View.VISIBLE);
            callback = new ConnectivityManager.NetworkCallback()
            {
                @Override
                public void onAvailable(@NonNull Network network) {
                    super.onAvailable(network);
                    finish();
                }

                @Override
                public void onLost(@NonNull Network network) {
                    super.onLost(network);
                    tvInternetCheck.setText(R.string.internet_check);
                    internetCheckBar.setVisibility(View.GONE);
                }
            };
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(
                    CONNECTIVITY_SERVICE
            );
            connectivityManager.registerNetworkCallback(new NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build(),callback);
        }
    }
    public void Retry(View view)
    {
        internetCheckBar.setVisibility(View.VISIBLE);
        if(Util.connectionAvailable(this))
        {
            finish();
        }
        else{
            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    internetCheckBar.setVisibility(View.GONE);
                }
            },1000);
        }
    }
    public void Close(View view)
    {
        finishAffinity();
    }
}