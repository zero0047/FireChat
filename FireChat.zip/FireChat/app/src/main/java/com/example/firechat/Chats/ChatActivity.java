package com.example.firechat.Chats;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.Extras;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.Comman.Util;
import com.example.firechat.R;
import com.example.firechat.SelectFriend.ShareFriendActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class ChatActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivSend,ivAttach,ivProfile;
    private TextView tvUsername;
    private EditText etMessage;
    private DatabaseReference mRootRef;
    private FirebaseAuth auth;
    private String currentUserId,chatUserId,chatUserName,photoName;
    private String currentPhotoPath;


    private RecyclerView rvMessages;
    private SwipeRefreshLayout srlMessages;
    private MessagesAdapter messagesAdapter;
    private List<MessageModel> messageModelList;

    private LinearLayout llProgress;

    private int currentPage = 1;
    private static final int RECORD_PER_PAGE = 30;
    private static final int REQUEST_CODE_PICK_IMAGE = 101;
    private static final int REQUEST_CODE_PICK_VIDEO = 103;
    private static final int REQUEST_CODE_CLICK_IMAGE = 102;
    private static final int REQUEST_CODE_TO_FORWARD = 104;
    private File photoFile;
    private Uri imageUri;


    private DatabaseReference databaseReferenceMessages;
    private ChildEventListener childEventListener;
    private BottomSheetDialog bottomSheetDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.darkyellow));

        ActionBar actionBar = getSupportActionBar();
        if(actionBar!=null)
        {
            actionBar.setTitle("");
            ViewGroup actionBarCustomLayout = (ViewGroup) getLayoutInflater().inflate(R.layout.custom_action_bar,null);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setElevation(0);

            actionBar.setCustomView(actionBarCustomLayout);
            actionBar.setDisplayOptions(actionBar.getDisplayOptions()|ActionBar.DISPLAY_SHOW_CUSTOM);

        }


        ivProfile = findViewById(R.id.ivProfileActionBar);
        tvUsername = findViewById(R.id.tvUsernameActionBar);
        ivSend = findViewById(R.id.ivSend);
        ivAttach = findViewById(R.id.ivAttach);
        etMessage = findViewById(R.id.etMessage);
        llProgress = findViewById(R.id.llProgress);
        ivSend.setOnClickListener(this);
        ivAttach.setOnClickListener(this);

        auth = FirebaseAuth.getInstance();
        mRootRef = FirebaseDatabase.getInstance().getReference();
        currentUserId = auth.getCurrentUser().getUid();
        if(getIntent().hasExtra(Extras.USER_KEY))
        {
            chatUserId = getIntent().getStringExtra(Extras.USER_KEY);
        }
        if(getIntent().hasExtra(Extras.USER_NAME))
        {
            chatUserName = getIntent().getStringExtra(Extras.USER_NAME);
        }

        tvUsername.setText(chatUserName);


            StorageReference fileStr = FirebaseStorage.getInstance().getReference()
                    .child(Constants.PROFILE_FOLDER + "/" + chatUserId + ".jpg");
            fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Glide.with(ChatActivity.this)
                            .load(uri)
                            .placeholder(R.drawable.default__better)
                            .error(R.drawable.default__better)
                            .into(ivProfile);
                }
            });
            fileStr.getDownloadUrl().addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });


        rvMessages = findViewById(R.id.rvMessages);
        srlMessages = findViewById(R.id.srlMessages);

        messageModelList = new ArrayList<>();
        messagesAdapter = new MessagesAdapter(this,messageModelList);

        rvMessages.setLayoutManager(new LinearLayoutManager(this));
        rvMessages.setAdapter(messagesAdapter);

        loadMessages();
        rvMessages.scrollToPosition(messageModelList.size()-1);
        srlMessages.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                currentPage++;
                messageModelList.clear();
                databaseReferenceMessages = mRootRef.child(NodeNames.MESSAGES).child(currentUserId).child(chatUserId);

                Query messageQuery = databaseReferenceMessages.limitToLast(currentPage*RECORD_PER_PAGE);

                if(childEventListener!=null)
                {
                    messageQuery.removeEventListener(childEventListener);
                }
                childEventListener = new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {


                        MessageModel messageModel = snapshot.getValue(MessageModel.class);
                        if (!messageModelList.contains(messageModel)) {
                            messageModelList.add(messageModel);
                            messagesAdapter.notifyDataSetChanged();
//                            rvMessages.scrollToPosition(messageModelList.size() - 1);
                            srlMessages.setRefreshing(false);
                        }
//                messageModelList.add(messageModel);
//                messagesAdapter.notifyDataSetChanged();
//                rvMessages.scrollToPosition(messageModelList.size()-1);
//                srlMessages.setRefreshing(false);
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        srlMessages.setRefreshing(false);
                    }
                };
                messageQuery.addChildEventListener(childEventListener);


            }
        });

        bottomSheetDialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.chat_file_layout,null);
        view.findViewById(R.id.llCamera).setOnClickListener(this);
        view.findViewById(R.id.llGallery).setOnClickListener(this);
        view.findViewById(R.id.llVideo).setOnClickListener(this);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        bottomSheetDialog.setContentView(view);

        if(getIntent().hasExtra(Extras.MESSAGE)
                &&getIntent().hasExtra(Extras.MESSAGE_ID)
                &&getIntent().hasExtra(Extras.MESSAGE_TYPE)){
            String message = getIntent().getStringExtra(Extras.MESSAGE);
            String messageId = getIntent().getStringExtra(Extras.MESSAGE_ID);
            final String messageType = getIntent().getStringExtra(Extras.MESSAGE_TYPE);
            DatabaseReference messageRef = mRootRef.child(NodeNames.MESSAGES).child(currentUserId)
                    .child(chatUserId).push();
            final String newMessageId = messageRef.getKey();

            if(messageType.equals(Constants.MSG_TYPE_TEXT)){
                SendMessage(message,messageType,newMessageId);
            }else{
                StorageReference strFile = FirebaseStorage.getInstance().getReference();
                String folderName = messageType.equals(Constants.MSG_TYPE_VIDEO)?Constants.MESSAGE_VIDEO:Constants.MESSAGE_IMAGE;
                String oldFileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?messageId+".mp4":messageId+".jpg";
                String newFileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?newMessageId+".mp4":newMessageId+".jpg";

                final String localFilePath = getExternalFilesDir(null).getAbsolutePath()+"/"+oldFileName;
                final File localFile = new File(localFilePath);
                final StorageReference fileRef = strFile.child(folderName).child(newFileName);

                strFile.child(folderName).child(oldFileName).getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        UploadTask uploadTask = fileRef.putFile(Uri.fromFile(localFile  ));
                        uploadProgress(uploadTask,fileRef,newMessageId,messageType);
                    }
                });
            }

        }

    }
    private void SendMessage(String msg,String msgType, String pushId)
    {
        try {
            if(!msg.equals(""))
            {
                HashMap messageMap = new HashMap();
                messageMap.put(NodeNames.MESSAGE_ID,pushId);
                messageMap.put(NodeNames.MESSAGE,msg);
                messageMap.put(NodeNames.MESSAGE_TYPE,msgType);
                messageMap.put(NodeNames.MESSAGE_FROM,currentUserId);
                messageMap.put(NodeNames.MESSAGE_TIME, ServerValue.TIMESTAMP);

                String currentUserRef = NodeNames.MESSAGES + "/" + currentUserId + "/" + chatUserId;
                String chatUserRef = NodeNames.MESSAGES + "/" + chatUserId + "/" + currentUserId;

                HashMap messageUserMap = new HashMap();
                messageUserMap.put(currentUserRef + "/" + pushId,messageMap);
                messageUserMap.put(chatUserRef + "/" + pushId,messageMap);

                etMessage.setText("");

                mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                        if(error!=null)
                        {
                            Toast.makeText(ChatActivity.this, getString(R.string.message_send_failed,error.getMessage())
                                    , Toast.LENGTH_SHORT).show();
                        }else
                        {
                            Toast.makeText(ChatActivity.this, R.string.message_sent_successfully, Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            }
        }catch (Exception e)
        {
            Toast.makeText(ChatActivity.this, getString(R.string.message_send_failed,e.getMessage())
                    , Toast.LENGTH_SHORT).show();
        }
    }

    private void loadMessages(){
        messageModelList.clear();
        databaseReferenceMessages = mRootRef.child(NodeNames.MESSAGES).child(currentUserId).child(chatUserId);

        Query messageQuery = databaseReferenceMessages.limitToLast(currentPage*RECORD_PER_PAGE);

        if(childEventListener!=null)
        {
            messageQuery.removeEventListener(childEventListener);
        }
        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {


                MessageModel messageModel = snapshot.getValue(MessageModel.class);
                if (!messageModelList.contains(messageModel)) {
                    messageModelList.add(messageModel);
                    messagesAdapter.notifyDataSetChanged();
                    rvMessages.scrollToPosition(messageModelList.size() - 1);
                    srlMessages.setRefreshing(false);
                }
//                messageModelList.add(messageModel);
//                messagesAdapter.notifyDataSetChanged();
//                rvMessages.scrollToPosition(messageModelList.size()-1);
//                srlMessages.setRefreshing(false);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                loadMessages();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                srlMessages.setRefreshing(false);
            }
        };
        messageQuery.addChildEventListener(childEventListener);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.ivSend:
                if(Util.connectionAvailable(this))
                {
                    DatabaseReference userMessagePush = FirebaseDatabase.getInstance().getReference()
                            .child(NodeNames.MESSAGES).child(currentUserId).child(chatUserId).push();
                    String pushId = userMessagePush.getKey();
                    SendMessage(etMessage.getText().toString().trim(), Constants.MSG_TYPE_TEXT,pushId);
                }else
                {
                    Toast.makeText(this, R.string.no_internet, Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.ivAttach:
                if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED)
                {
                    if(bottomSheetDialog!=null)
                        bottomSheetDialog.show();

                }else
                {
                    ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);
                }
                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                //View view = getCurrentFocus();
                if(inputMethodManager!=null)
                    inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(),0);
                break;

            case R.id.llCamera:
                bottomSheetDialog.dismiss();
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                // Ensure that there's a camera activity to handle the intent
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    // Create the File where the photo should go
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException ex) {
                        // Error occurred while creating the File

                    }
                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                       Uri photoUri = FileProvider.getUriForFile(this,
                                "com.example.android.fileprovider",
                                photoFile);
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri.toString());

                        startActivityForResult(takePictureIntent, REQUEST_CODE_CLICK_IMAGE);
                    }
                }
                break;

            case R.id.llGallery:
                bottomSheetDialog.dismiss();
                Intent intentGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentGallery,REQUEST_CODE_PICK_IMAGE);
                break;

            case R.id.llVideo:
                bottomSheetDialog.dismiss();
                Intent intentVideo = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentVideo,REQUEST_CODE_PICK_VIDEO);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode != RESULT_CANCELED&&data!=null)
        {
            if(requestCode==REQUEST_CODE_CLICK_IMAGE)//Camera
            {

//                    Bitmap thumbnail = MediaStore.Images.Media.getBitmap(
//                            getContentResolver(), imageUri);
                    String uri = data.getStringExtra(MediaStore.EXTRA_OUTPUT);
                    Log.e("Has_URI",uri);
                    uploadFile(Uri.parse(uri),Constants.MSG_TYPE_IMAGE);
                    //imgView.setImageBitmap(thumbnail);
                    //imageurl = getRealPathFromURI(imageUri);
//                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
//                        thumbnail.compress(Bitmap.CompressFormat.JPEG,100,bytes);
//                        uploadBytes(bytes,Constants.MSG_TYPE_IMAGE);




//                if(data!=null)
//                {
//                     photoUriToBeUploaded = data.getData();
//                    uploadFile(photoUriToBeUploaded,Constants.MSG_TYPE_IMAGE);
//                }if(photoUriToBeUploaded==null && photoFile!=null)
//            {
//                 photoUriToBeUploaded = Uri.fromFile(new File(String.valueOf(photoFile)));
//                uploadFile(photoUriToBeUploaded,Constants.MSG_TYPE_IMAGE);
//            }






//                if (resultCode==Activity.RESULT_OK){
//                    String uri = data.getStringExtra("name");
//                    Uri photoSaveUri = Uri.parse(uri);
//                    uploadFile(photoSaveUri , Constants.MSG_TYPE_IMAGE);
//                }
//                Uri tempUri = data.getData();

               // Bitmap bitmap = (Bitmap) data.getExtras().get("name");

//                Bitmap photo = (Bitmap) data.getExtras().get("data");
//                // CALL THIS METHOD TO GET THE URI FROM THE BITMAP
//                Uri tempUri = getImageUri(getApplicationContext(), photo);
                //uploadFile(tempUri , Constants.MSG_TYPE_IMAGE);
//                try {
//                    if(  Uri.parse(String.valueOf(tempUri))!=null   ){
//                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver()
//                                , Uri.parse(String.valueOf(tempUri)));
//                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
//                        bitmap.compress(Bitmap.CompressFormat.JPEG,100,bytes);
//                        uploadBytes(bytes,Constants.MSG_TYPE_IMAGE);
//
//                    }
//                }
//                catch (Exception e) {
//                    //handle exception
//                }



//                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
//                Uri selectedImageUri = data.getData();
//                Bitmap bitmap = null;
//                try {
//                    bitmap = BitmapFactory.decodeStream(this.getContentResolver().openInputStream(selectedImageUri)
//                            , null, null);
//                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
//                    bitmap.compress(Bitmap.CompressFormat.JPEG,100,bytes);
//                    uploadBytes(bytes,Constants.MSG_TYPE_IMAGE);
//                } catch (FileNotFoundException e) {
//                    e.printStackTrace();
//                }




            }else if(requestCode==REQUEST_CODE_PICK_IMAGE)//Gallery
            {
                Uri uri = data.getData();
                uploadFile(uri , Constants.MSG_TYPE_IMAGE);
            }
            else if(requestCode==REQUEST_CODE_PICK_VIDEO)//Video
            {
                Uri uri = data.getData();
                uploadFile(uri , Constants.MSG_TYPE_VIDEO);
            }
            else if(requestCode==REQUEST_CODE_TO_FORWARD){
                Intent intent = new Intent(this,ChatActivity.class);
                intent.putExtra(Extras.USER_KEY,data.getStringExtra(Extras.USER_KEY));
                intent.putExtra(Extras.USER_NAME,data.getStringExtra(Extras.USER_NAME));
                intent.putExtra(Extras.PHOTO_NAME,data.getStringExtra(Extras.PHOTO_NAME));

                intent.putExtra(Extras.MESSAGE,data.getStringExtra(Extras.MESSAGE));
                intent.putExtra(Extras.MESSAGE_TYPE,data.getStringExtra(Extras.MESSAGE_TYPE));
                intent.putExtra(Extras.MESSAGE_ID,data.getStringExtra(Extras.MESSAGE_ID));
                startActivity(intent);
                finish();
            }
        }
    }

    private void uploadFile(Uri uri, String messageType)
    {
        DatabaseReference databaseReference = mRootRef.child(NodeNames.MESSAGES).child(currentUserId).child(chatUserId).push();
        String pushId = databaseReference.getKey();

        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        String folderName = messageType.equals(Constants.MSG_TYPE_VIDEO)?Constants.MESSAGE_VIDEO:Constants.MESSAGE_IMAGE;
        String fileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?pushId + ".mp4":pushId + ".jpg";

        StorageReference fileRef = storageReference.child(folderName).child(fileName);
        UploadTask uploadTask = fileRef.putFile(uri);
        uploadProgress(uploadTask,fileRef,pushId,messageType);

    }

    private void uploadBytes(ByteArrayOutputStream bytes , String messageType){
        DatabaseReference databaseReference = mRootRef.child(NodeNames.MESSAGES).child(currentUserId).child(chatUserId).push();
        String pushId = databaseReference.getKey();

        StorageReference storageReference = FirebaseStorage.getInstance().getReference();
        String folderName = messageType.equals(Constants.MSG_TYPE_VIDEO)?Constants.MESSAGE_VIDEO:Constants.MESSAGE_IMAGE;
        String fileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?pushId + ".mp4":pushId + ".jpg";

        StorageReference fileRef = storageReference.child(folderName).child(fileName);
        UploadTask uploadTask = fileRef.putBytes(bytes.toByteArray());
        uploadProgress(uploadTask,fileRef,pushId,messageType);
    }

    private void uploadProgress(final UploadTask task , final StorageReference filePath , final String pushId , final String messageType)
    {
        final View view = getLayoutInflater().inflate(R.layout.file_progress,null);
        final ProgressBar pbProgress = view.findViewById(R.id.pbProgress);
        final TextView tvProgress = view.findViewById(R.id.tvFileProgress);
        final ImageView ivPause = view.findViewById(R.id.ivPause);
        final ImageView ivPlay = view.findViewById(R.id.ivPlay);
        ImageView ivCancel = view.findViewById(R.id.ivCancel);

        ivPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task.pause();
                ivPlay.setVisibility(View.VISIBLE);
                ivPause.setVisibility(View.GONE);
            }
        });

        ivPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task.resume();
                ivPause.setVisibility(View.VISIBLE);
                ivPlay.setVisibility(View.GONE);
            }
        });

        ivCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                task.cancel();
            }
        });
        llProgress.addView(view);
        tvProgress.setText(getString(R.string.upload_progress,messageType,"0"));

        task.addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                pbProgress.setProgress((int) progress);
                tvProgress.setText(getString(R.string.upload_progress, messageType,
                        String.valueOf(pbProgress.getProgress())));
            }
        }).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                llProgress.removeView(view);
                if (task.isSuccessful()) {
                    filePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            String downloadURL = uri.toString();
                            SendMessage(downloadURL, messageType, pushId);
                        }
                    });
                }
            }
        });

        task.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                llProgress.removeView(view);
                Toast.makeText(ChatActivity.this,
                        getString(R.string.failed_to_upoad,e.getMessage()),
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                if(bottomSheetDialog!=null)
                    bottomSheetDialog.show();
            }else
            {
                Toast.makeText(this, "Permission required to access files", Toast.LENGTH_SHORT).show();
            }
        }else if(requestCode==2)
        {
            if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {

            }else
            {
                Toast.makeText(this, "Permission required to download files", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();
        switch (itemId)
        {
            case  android.R.id.home:
                finish();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    public void deleteMessage(final String messageId, final String messageType){
        DatabaseReference databaseReference = mRootRef.child(NodeNames.MESSAGES).child(currentUserId)
                .child(chatUserId).child(messageId);
        databaseReference.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    DatabaseReference databaseReferenceChat = mRootRef.child(NodeNames.MESSAGES).child(chatUserId)
                            .child(currentUserId).child(messageId);
                    databaseReferenceChat.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(ChatActivity.this, R.string.message_delete_success,
                                        Toast.LENGTH_SHORT).show();
                                if(!messageType.equals(Constants.MSG_TYPE_TEXT))
                                {
                                    StorageReference rootRef = FirebaseStorage.getInstance().getReference();
                                    String folder = messageType.equals(Constants.MSG_TYPE_VIDEO)?Constants.MESSAGE_VIDEO:Constants.MESSAGE_IMAGE;
                                    String fileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?messageId+".mp4":messageId+".jpg";
                                    StorageReference fileRef = rootRef.child(folder).child(fileName);
                                    fileRef.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(!task.isSuccessful())
                                            {
                                                Toast.makeText(ChatActivity.this,getString(R.string.failed_file_deletion,task.getException()),
                                                        Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            }else
                            {
                                Toast.makeText(ChatActivity.this,getString(R.string.delete_message_failed,task.getException()),
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else
                {
                    Toast.makeText(ChatActivity.this,getString(R.string.delete_message_failed,task.getException()),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public void downloadFile(String messageId , final String messageType, final boolean isShare)
    {
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},2);
        }else{
            String folder = messageType.equals(Constants.MSG_TYPE_VIDEO)?Constants.MESSAGE_VIDEO:Constants.MESSAGE_IMAGE;
            String fileName = messageType.equals(Constants.MSG_TYPE_VIDEO)?messageId+".mp4":messageId+".jpg";
            StorageReference fileRef = FirebaseStorage.getInstance().getReference().child(folder).child(fileName);

           final String localFilePath = getExternalFilesDir(null).getAbsolutePath() + "/" + fileName;
            //final String localFilePath = "/storage/emulated/0/FireChat/"+fileName;
               // final String localFilePath = (getExternalMediaDirs()+"/"+fileName);
            //final String localFilePath = Environment.getExternalStorageDirectory().getAbsolutePath()+"/" + fileName;

            //String root = Environment.getExternalStorageDirectory().getAbsolutePath()+"/" + fileName;
            //File myDir = new File(root + "/saved_images");


            //final File localFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), fileName);


            final File localFile = new File(localFilePath);
            if (!localFile.exists()) {
                localFile.mkdirs();
            }

//            if(!localFile.exists()){
//                try {
//                    localFile.createNewFile();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }

            if(localFile.isFile()&&isShare){
                Intent intentShare = new Intent();
                intentShare.setAction(Intent.ACTION_SEND);
                intentShare.putExtra(Intent.EXTRA_STREAM, Uri.parse(localFilePath));
                if (messageType.equals(Constants.MSG_TYPE_VIDEO)) {
                    intentShare.setType("video/mp4");
                }
                if (messageType.equals(Constants.MSG_TYPE_IMAGE)) {
                    intentShare.setType("image/jpg");
                }
                startActivity(Intent.createChooser(intentShare, getString(R.string.share_with)));

            }

            if(!localFile.isFile()) {
                Log.e("Entered","SUCCESS");
                try {
                    if (localFile.exists() || localFile.createNewFile()) {
                        Log.e("TRY ENTERED","SUCCESS");
                        final FileDownloadTask fileDownloadTask = fileRef.getFile(localFile);

                        final View view = getLayoutInflater().inflate(R.layout.file_progress, null);
                        final ProgressBar pbProgress = view.findViewById(R.id.pbProgress);
                        final TextView tvProgress = view.findViewById(R.id.tvFileProgress);
                        final ImageView ivPause = view.findViewById(R.id.ivPause);
                        final ImageView ivPlay = view.findViewById(R.id.ivPlay);
                        ImageView ivCancel = view.findViewById(R.id.ivCancel);

                        ivPause.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                fileDownloadTask.pause();
                                ivPlay.setVisibility(View.VISIBLE);
                                ivPause.setVisibility(View.GONE);
                            }
                        });

                        ivPlay.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                fileDownloadTask.resume();
                                ivPause.setVisibility(View.VISIBLE);
                                ivPlay.setVisibility(View.GONE);
                            }
                        });

                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                fileDownloadTask.cancel();
                            }
                        });
                        llProgress.addView(view);
                        tvProgress.setText(getString(R.string.download_progress, messageType, "0"));

                        fileDownloadTask.addOnProgressListener(new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull FileDownloadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                pbProgress.setProgress((int) progress);
                                tvProgress.setText(getString(R.string.download_progress, messageType,
                                        String.valueOf(pbProgress.getProgress())));
                            }
                        });

                        fileDownloadTask.addOnCompleteListener(new OnCompleteListener<FileDownloadTask.TaskSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<FileDownloadTask.TaskSnapshot> task) {
                                llProgress.removeView(view);
                                if (task.isSuccessful()) {

                                    if (isShare) {

                                        Intent intentShare = new Intent();
                                        intentShare.setAction(Intent.ACTION_SEND);
                                        intentShare.putExtra(Intent.EXTRA_STREAM, Uri.parse(localFilePath));
                                        if (messageType.equals(Constants.MSG_TYPE_VIDEO)) {
                                            intentShare.setType("video/mp4");
                                        }
                                        if (messageType.equals(Constants.MSG_TYPE_IMAGE)) {
                                            intentShare.setType("image/jpg");
                                        }
                                        startActivity(Intent.createChooser(intentShare, getString(R.string.share_with)));

                                    } else {
                                        Snackbar snackbar = Snackbar.make(llProgress, getString(R.string.file_downloaded_succesfully)
                                                , Snackbar.LENGTH_INDEFINITE);

                                        snackbar.setAction(R.string.view, new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                //Log.e("URI",localFilePath);
                                                Uri uri = Uri.parse(localFilePath);

                                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                                if (messageType.equals(Constants.MSG_TYPE_VIDEO)) {
                                                    intent.setDataAndType(uri, "video/mp4");
                                                } else if (messageType.equals(Constants.MSG_TYPE_IMAGE)) {
                                                    Log.e("ENTERED", "SUCCESS");
                                                    intent.setDataAndType(uri, "image/*");
                                                }
                                                startActivity(intent);
                                            }
                                        });

                                        snackbar.show();
                                    }
                                }
                            }

                        });


                        fileDownloadTask.addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                llProgress.removeView(view);
                                Toast.makeText(ChatActivity.this,
                                        getString(R.string.failed_to_download, e.getMessage()),
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else  {
                        Toast.makeText(this, R.string.cant_store_file, Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(ChatActivity.this,
                            getString(R.string.failed_to_download, e.getMessage()),
                            Toast.LENGTH_SHORT).show();
                }
            }else if(!isShare){
                Toast.makeText(this, R.string.file_already_exists, Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void forwardMessage(String selectedMessageId, String selectedMessage, String selectedMessageType) {
        Intent intent = new Intent(this, ShareFriendActivity.class);
        intent.putExtra(Extras.MESSAGE,selectedMessage);
        intent.putExtra(Extras.MESSAGE_ID,selectedMessageId);
        intent.putExtra(Extras.MESSAGE_TYPE,selectedMessageType);
        startActivityForResult(intent,REQUEST_CODE_TO_FORWARD);
    }
}