package com.example.firechat.FindFriends;

public class FindFriends {
    private String username;
    private String photoId;
    private String userId;
    private Boolean requestSent;

    public FindFriends(String username, String photoId, String userId, Boolean requestSent) {
        this.username = username;
        this.photoId = photoId;
        this.userId = userId;
        this.requestSent = requestSent;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhotoId() {
        return photoId;
    }

    public void setPhotoId(String photoId) {
        this.photoId = photoId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Boolean getRequestSent() {
        return requestSent;
    }

    public void setRequestSent(Boolean requestSent) {
        this.requestSent = requestSent;
    }
}
