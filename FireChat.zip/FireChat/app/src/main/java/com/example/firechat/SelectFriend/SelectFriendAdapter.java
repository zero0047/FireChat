package com.example.firechat.SelectFriend;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class SelectFriendAdapter extends RecyclerView.Adapter<SelectFriendAdapter.SelectFriendViewHolder> {

    private Context context;
    private List<SelectFriendModel> selectFriendModelList;

    public SelectFriendAdapter(Context context, List<SelectFriendModel> selectFriendModelList) {
        this.context = context;
        this.selectFriendModelList = selectFriendModelList;
    }

    @NonNull
    @Override
    public SelectFriendAdapter.SelectFriendViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.share_friend_layout,parent,false);
        return new SelectFriendViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SelectFriendAdapter.SelectFriendViewHolder holder, int position) {
            final SelectFriendModel selectFriendModel = selectFriendModelList.get(position);
            holder.tvFullName.setText(selectFriendModel.getUserName());

        StorageReference fileStr = FirebaseStorage.getInstance().getReference()
                .child(Constants.PROFILE_FOLDER+"/"+selectFriendModel.getUserId()+".jpg");
        fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(context)
                        .load(uri)
                        .placeholder(R.drawable.default__better)
                        .error(R.drawable.default__better)
                        .into(holder.ivProfile);
            }
        });

        holder.llSelectFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(context instanceof ShareFriendActivity){
                    ((ShareFriendActivity)context).returnSelectedFriend(selectFriendModel.getUserId(),selectFriendModel.getUserName(),
                            selectFriendModel.getUserId()+".jpg");
                }
            }
        });



    }

    @Override
    public int getItemCount() {
        return selectFriendModelList.size();
    }

    @Override public int getItemViewType(int position) {        return position;}

    public void filterList(ArrayList<SelectFriendModel> filteredList) {
        selectFriendModelList = filteredList;
        notifyDataSetChanged();
    }

    public class SelectFriendViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llSelectFriend;
        ImageView ivProfile;
        TextView tvFullName;


        public SelectFriendViewHolder(@NonNull View itemView) {
            super(itemView);
            llSelectFriend = itemView.findViewById(R.id.llSelectFriend);
            ivProfile = itemView.findViewById(R.id.ivProfile);
            tvFullName = itemView.findViewById(R.id.tvFullName);
        }
    }
}
