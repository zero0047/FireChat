package com.example.firechat.Comman;

public class Constants {
    public static final String PROFILE_FOLDER = "images";
    public static final String MESSAGE_IMAGE = "message_image";
    public static final String MESSAGE_VIDEO = "message_video";



    public static final String REQUEST_SENT = "sent";
    public static final String REQUEST_RECEIVED = "received";
    public static final String REQUEST_ACCEPTED = "accepted";


    public static final String MSG_TYPE_TEXT = "text";
    public static final String MSG_TYPE_IMAGE = "image";
    public static final String MSG_TYPE_VIDEO = "video";
}
