package com.example.firechat.password;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.example.firechat.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ResetPasswordActivity extends AppCompatActivity {
    private TextInputEditText etEmail;
    private String email;
    private TextView tvResetInstructions,tvResendIn;
    Button btnLogin;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);


        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorAccent));

        if(getSupportActionBar()!=null)
            getSupportActionBar().hide();



        etEmail = findViewById(R.id.etEmail);
        tvResetInstructions = findViewById(R.id.tvResetInstructions);
        tvResendIn = findViewById(R.id.tvResendIn);
        btnLogin = findViewById(R.id.btnLogin);
        tvResetInstructions.setText("");
        tvResendIn.setText("");
    }
    public void resetPassword(View view)
    {
        dialog = new ProgressDialog(this);
        dialog.setMessage("Sending recovery email.....");

        email = etEmail.getText().toString().trim();
        if(email.equals(""))
        {
            etEmail.setError("Enter email");
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            etEmail.setError("Incorrect email");
        }else
        {
            dialog.show();
            FirebaseAuth auth = FirebaseAuth.getInstance();
            auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    dialog.dismiss();
                    if(task.isSuccessful())
                    {
                        tvResetInstructions.setText(getString(R.string.reset_instructions,email));
                        new CountDownTimer(60000,1000){

                            @Override
                            public void onTick(long millisUntilFinished) {
                                btnLogin.setEnabled(false);
                                tvResendIn.setText(getString(R.string.reset_in_60,
                                        String.valueOf(millisUntilFinished/1000)));
                            }

                            @Override
                            public void onFinish() {
                                tvResendIn.setVisibility(View.GONE);
                                tvResetInstructions.setVisibility(View.GONE);
                                btnLogin.setEnabled(true);
                            }
                        }.start();
                    }else{
                        tvResetInstructions.setText("Something went wrong: "+ task.getException());
                        new CountDownTimer(60000,1000){

                            @Override
                            public void onTick(long millisUntilFinished) {
                                btnLogin.setEnabled(false);
                                tvResendIn.setText(getString(R.string.reset_in_60,
                                        String.valueOf(millisUntilFinished/1000)));
                            }

                            @Override
                            public void onFinish() {
                                tvResendIn.setVisibility(View.GONE);
                                tvResetInstructions.setVisibility(View.GONE);
                                btnLogin.setEnabled(true);
                            }
                        }.start();
                    }
                }
            });
        }
    }
    public void close(View view)
    {
        finish();
    }
}