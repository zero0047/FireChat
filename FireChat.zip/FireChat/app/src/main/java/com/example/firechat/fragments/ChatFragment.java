package com.example.firechat.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firechat.Chats.ChatListAdapter;
import com.example.firechat.Chats.ChatListModel;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * A simple {@link Fragment} subclass.
 */
public class ChatFragment extends Fragment {

    private RecyclerView rvChat;
    private TextView tvEmptyList;
    private View progressBar;
    private EditText etSearch;
    private SearchView searchView;
    private SwipeRefreshLayout srlChat;


    DatabaseReference databaseReferenceChats,databaseReferenceUsers;
    private Query query;
    private ChildEventListener childEventListener;
    private ChatListAdapter chatListAdapter;
    FirebaseUser currentUser;
    private List<ChatListModel> chatListModelList;

    public ChatFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chat, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rvChat = view.findViewById(R.id.rvChat);
        progressBar = view.findViewById(R.id.progressBar);
        tvEmptyList = view.findViewById(R.id.tvChatsAppear);
        searchView = view.findViewById(R.id.mySearch);
        //etSearch = view.findViewById(R.id.etSearch);
//        srlChat = view.findViewById(R.id.srlChat);

        chatListModelList = new ArrayList<>();
        chatListAdapter  = new ChatListAdapter(getActivity(),chatListModelList);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        rvChat.setLayoutManager(linearLayoutManager);
        rvChat.setAdapter(chatListAdapter);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        databaseReferenceUsers = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.USERS);
        databaseReferenceChats = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.CHATS).child(currentUser.getUid());

        load();






//        srlChat.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
//            @Override
//            public void onRefresh() {
//                load();
//            }
//        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filter(newText);
                return false;
            }
        });

    }



    private void load()
    {
        if(childEventListener!=null)
        {
            query.removeEventListener(childEventListener);
        }
        query = databaseReferenceChats.orderByChild(NodeNames.TIME_STAMP);

        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                updateList(snapshot,true,snapshot.getKey());
//                srlChat.setRefreshing(false);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };
        query.addChildEventListener(childEventListener);
        Log.e("Times","NUMBERS");
        progressBar.setVisibility(View.VISIBLE);
        tvEmptyList.setVisibility(View.VISIBLE);
    }

    private void updateList(DataSnapshot dataSnapshot, boolean isNew, final String userId)
    {
        progressBar.setVisibility(View.GONE);
        tvEmptyList.setVisibility(View.GONE);
        final String lastMessage , unreadCount , lastMessageTime;
        lastMessage = "";
        unreadCount = "";
        lastMessageTime = "";

        databaseReferenceUsers.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String  fullName = snapshot.child(NodeNames.NAME).getValue()!=null?
                        snapshot.child(NodeNames.NAME).getValue().toString():"";
                String  photoName = snapshot.child(NodeNames.NAME).getValue()!=null?
                        snapshot.child(NodeNames.NAME).getValue().toString():"";

                ChatListModel chatListModel = new ChatListModel(userId,fullName,photoName,unreadCount,lastMessage,lastMessageTime);
                chatListModelList.add(chatListModel);
                chatListAdapter.notifyDataSetChanged();
//                srlChat.setRefreshing(false);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
                tvEmptyList.setVisibility(View.GONE);
                Toast.makeText(getActivity(), "Failed to fetch the chat list: "+error.getMessage(), Toast.LENGTH_SHORT).show();
//                srlChat.setRefreshing(false);
            }
        });

    }

    private void filter(String text) {
        ArrayList<ChatListModel> filteredList = new ArrayList<>();

        for (ChatListModel item : chatListModelList)
        {
            if (item.getUserName().toLowerCase().contains(text.toLowerCase()))
            {
                filteredList.add(item);
            }
        }

        chatListAdapter.filterList(filteredList);
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        query.removeEventListener(childEventListener);
    }
}