package com.example.firechat.Chats;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.R;
import com.google.firebase.auth.FirebaseAuth;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

//import android.view.ActionMode;



public class MessagesAdapter extends RecyclerView.Adapter<MessagesAdapter.MessageViewHolder> {


    private Context context;
    private List<MessageModel> messageModelList;
    private FirebaseAuth auth;
    private ActionMode actionMode;
    private ConstraintLayout selectedView;
    private String fromUserIdGlobal,currentUserIdGlobal;


    public MessagesAdapter(Context context, List<MessageModel> messageModelList) {
        this.context = context;
        this.messageModelList = messageModelList;
    }

    @NonNull
    @Override
    public MessagesAdapter.MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.message_layout,parent,false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MessagesAdapter.MessageViewHolder holder, int position) {
            MessageModel messageModel = messageModelList.get(position);
            auth = FirebaseAuth.getInstance();
            String currentUserId = auth.getCurrentUser().getUid();
            currentUserIdGlobal = currentUserId;
            String fromUserId = messageModel.getMessageFrom();
            fromUserIdGlobal = fromUserId;

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        String dateTime = simpleDateFormat.format(new Date(messageModel.getMessageTime()));
        String[] splitString = dateTime.split(" ");
        String messageTime = splitString[1];

        if(fromUserId.equals(currentUserId))
        {
            if(messageModel.getMessage_Type().equals(Constants.MSG_TYPE_TEXT))
            {
                holder.llSent.setVisibility(View.VISIBLE);
                holder.llSentImage.setVisibility(View.GONE);
            }
            else
            {
                holder.llSent.setVisibility(View.GONE);
                holder.llSentImage.setVisibility(View.VISIBLE);
            }


            holder.llReceived.setVisibility(View.GONE);
            holder.llReceivedImage.setVisibility(View.GONE);
            holder.tvSentMessage.setText(messageModel.getMessage());
            holder.tvSentMessageTime.setText(messageTime);
            holder.tvSentImageTime.setText(messageTime);

            Glide.with(context)
                    .load(messageModel.getMessage())
                    .placeholder(R.drawable.ic_image)
                    .into(holder.ivSent);
        }else
        {
            if(messageModel.getMessage_Type().equals(Constants.MSG_TYPE_TEXT))
            {
                holder.llReceived.setVisibility(View.VISIBLE);
                holder.llReceivedImage.setVisibility(View.GONE);
            }else
            {
                holder.llReceived.setVisibility(View.GONE);
                holder.llReceivedImage.setVisibility(View.VISIBLE);
            }


            holder.llSent.setVisibility(View.GONE);
            holder.llSentImage.setVisibility(View.GONE);
            holder.tvReceivedMessage.setText(messageModel.getMessage());
            holder.tvReceivedMessageTime.setText(messageTime);
            holder.tvReceivedImageTime.setText(messageTime);

            Glide.with(context)
                    .load(messageModel.getMessage())
                    .placeholder(R.drawable.ic_image)
                    .into(holder.ivReceived);
        }
        holder.clMessage.setTag(R.id.TAG_MESSAGE,messageModel.getMessage());
        holder.clMessage.setTag(R.id.TAG_MESSAGE_ID,messageModel.getMessageId());
        holder.clMessage.setTag(R.id.TAG_MESSAGE_TYPE,messageModel.getMessage_Type());

        holder.clMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messageType = v.getTag(R.id.TAG_MESSAGE_TYPE).toString();
                Uri uri = Uri.parse(v.getTag(R.id.TAG_MESSAGE).toString());
                if(messageType.equals(Constants.MSG_TYPE_IMAGE))
                {
                    Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                    intent.setDataAndType(uri,"image/jpg");
                    context.startActivity(intent);
                }else if(messageType.equals(Constants.MSG_TYPE_VIDEO))
                {
                    Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                    intent.setDataAndType(uri,"video/mp4");
                    context.startActivity(intent);
                }
            }
        });

        holder.clMessage.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
//                if(actionMode!=null) {
//                    return false;
//                }
                selectedView = holder.clMessage;
                actionMode = ((AppCompatActivity)context).startSupportActionMode(callbackActionMode);
                holder.clMessage.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));
                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return messageModelList.size();
    }
    @Override public int getItemViewType(int position) {        return position;}

    public class MessageViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout llSent,llReceived,llSentImage,llReceivedImage;
        private TextView tvSentMessage,tvReceivedMessage,tvSentMessageTime,tvReceivedMessageTime;
        private ImageView ivSent,ivReceived;
        private TextView tvSentImageTime,tvReceivedImageTime;
        private ConstraintLayout clMessage;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);
            llSent = itemView.findViewById(R.id.llSent);
            llSentImage = itemView.findViewById(R.id.llSentImage);
            llReceived = itemView.findViewById(R.id.llReceived);
            llReceivedImage = itemView.findViewById(R.id.llReceivedImage);
            tvSentMessage = itemView.findViewById(R.id.tvSentMessage);
            ivSent = itemView.findViewById(R.id.ivSentImage);
            ivReceived = itemView.findViewById(R.id.ivReceivedImage);
            tvSentMessageTime = itemView.findViewById(R.id.tvSentMessageTime);
            tvSentImageTime = itemView.findViewById(R.id.tvSentImageTime);
            tvReceivedMessage = itemView.findViewById(R.id.tvReceivedMessage);
            tvReceivedMessageTime = itemView.findViewById(R.id.tvReceivedMessageTime);
            tvReceivedImageTime = itemView.findViewById(R.id.tvReceivedImageTime);
            clMessage = itemView.findViewById(R.id.clMessage);
        }
    }
    public ActionMode.Callback callbackActionMode = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.menu_chat_options,menu);
            String selectedMessageType = (String) selectedView.getTag(R.id.TAG_MESSAGE_TYPE);
            if(selectedMessageType.equals(Constants.MSG_TYPE_TEXT))
            {
                MenuItem menuItem = menu.findItem(R.id.menuDownload);
                menuItem.setVisible(false);
            }
//            if(!fromUserIdGlobal.equals(currentUserIdGlobal))
//            {
//                MenuItem menuItem = menu.findItem((R.id.menuDelete));
//                menuItem.setVisible(false);
//            }


            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
           String selectedMessageType = (String) selectedView.getTag(R.id.TAG_MESSAGE_TYPE);
           String selectedMessage = (String) selectedView.getTag(R.id.TAG_MESSAGE);
           String selectedMessageId = (String) selectedView.getTag(R.id.TAG_MESSAGE_ID);


            int itemId = item.getItemId();
            switch (itemId)
            {
                case R.id.menuDelete:
                    if(context instanceof ChatActivity)
                    {
                        ((ChatActivity) context).deleteMessage(selectedMessageId,selectedMessageType);
                    }
                    mode.finish();
                    break;
                case R.id.menuForward:
                    if(context instanceof ChatActivity)
                    {
                        ((ChatActivity) context).forwardMessage(selectedMessageId,selectedMessage,selectedMessageType);
                    }

                    mode.finish();
                    break;
                case R.id.menuShare:
                    if(selectedMessageType.equals(Constants.MSG_TYPE_TEXT)) {
                        Intent intent = new Intent();
                        intent.setAction(Intent.ACTION_SEND);
                        intent.putExtra(Intent.EXTRA_TEXT, selectedMessage);
                        intent.setType("text/plain");
                        context.startActivity(intent);
                    }else
                    {
                        if(context instanceof ChatActivity)
                        {
                            ((ChatActivity) context).downloadFile(selectedMessageId,selectedMessageType,true);
                        }
                    }
                    mode.finish();
                    break;
                case R.id.menuDownload:
                    if(context instanceof ChatActivity)
                    {
                        ((ChatActivity) context).downloadFile(selectedMessageId,selectedMessageType,false);
                    }
                    mode.finish();
                    break;
            }
            return false;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            selectedView.setBackgroundColor(context.getResources().getColor(R.color.chat_Activity));

        }
    };
}
