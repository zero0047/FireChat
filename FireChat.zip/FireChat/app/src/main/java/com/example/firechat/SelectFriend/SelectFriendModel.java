package com.example.firechat.SelectFriend;

public class SelectFriendModel {
    private String userId;
    private String photoName;
    private String userName;

    public SelectFriendModel(String userId, String photoName, String userName) {
        this.userId = userId;
        this.photoName = photoName;
        this.userName = userName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPhotoName() {
        return photoName;
    }

    public void setPhotoName(String photoName) {
        this.photoName = photoName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
