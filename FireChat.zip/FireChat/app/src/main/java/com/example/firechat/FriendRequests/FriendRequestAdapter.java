package com.example.firechat.FriendRequests;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FriendRequestAdapter extends RecyclerView.Adapter<FriendRequestAdapter.FriendRequestViewHolder> {

    private Context context;
    private List<FriendRequestModel> friendRequestModelList;
    DatabaseReference databaseReference , databaseReferenceChat;
    FirebaseUser currentUser;

    public FriendRequestAdapter(Context context, List<FriendRequestModel> friendRequestModelList) {
        this.context = context;
        this.friendRequestModelList = friendRequestModelList;
    }




    @NonNull
    @Override
    public FriendRequestAdapter.FriendRequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.friend_request_layout,parent,false);

        return new  FriendRequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FriendRequestAdapter.FriendRequestViewHolder holder, int position) {
        final FriendRequestModel friendRequestModel = friendRequestModelList.get(position);
        holder.username.setText(friendRequestModel.getUsername());

        StorageReference fileStr = FirebaseStorage.getInstance().getReference()
                .child(Constants.PROFILE_FOLDER + "/" + friendRequestModel.getUserId()+".jpg");
        fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(context)
                .load(uri)
                        .placeholder(R.drawable.default__better)
                .error(R.drawable.default__better)
                        .into(holder.profileImage);
            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.FRIEND_REQUEST);
        databaseReferenceChat = FirebaseDatabase.getInstance().getReference()
                .child(NodeNames.CHATS);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        holder.btn_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.pbDecision.setVisibility(View.VISIBLE);
                holder.btn_deny.setVisibility(View.GONE);
                holder.btn_accept.setVisibility(View.GONE);

                databaseReferenceChat.child(currentUser.getUid()).child(friendRequestModel.getUserId())
                        .child(NodeNames.TIME_STAMP).setValue(ServerValue.TIMESTAMP)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            databaseReferenceChat.child(friendRequestModel.getUserId()).child(currentUser.getUid())
                                    .child(NodeNames.TIME_STAMP).setValue(ServerValue.TIMESTAMP)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                    {
                                        databaseReference.child(currentUser.getUid())
                                                .child(friendRequestModel.getUserId())
                                                .child(NodeNames.FRIEND_REQUEST_TYPE)
                                                .setValue(Constants.REQUEST_ACCEPTED)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if(task.isSuccessful())
                                                {
                                                    databaseReference.child(friendRequestModel.getUserId())
                                                            .child(currentUser.getUid())
                                                            .child(NodeNames.FRIEND_REQUEST_TYPE)
                                                            .setValue(Constants.REQUEST_ACCEPTED)
                                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {
                                                            if(task.isSuccessful())
                                                            {
                                                                Toast.makeText(context,R.string.accept_request_success
                                                                        , Toast.LENGTH_SHORT).show();
                                                                holder.pbDecision.setVisibility(View.GONE);
                                                                holder.btn_deny.setVisibility(View.VISIBLE);
                                                                holder.btn_accept.setVisibility(View.VISIBLE);
                                                            }else
                                                            {
                                                                handlingException(holder,task.getException());
                                                            }
                                                        }
                                                    });
                                                }else
                                                {
                                                    handlingException(holder,task.getException());
                                                }
                                            }
                                        });


                                    }else
                                    {
                                        handlingException(holder,task.getException());
                                    }
                                }
                            });


                        }else
                        {
                            handlingException(holder,task.getException());
                        }
                    }
                });



            }
        });
        holder.btn_deny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.pbDecision.setVisibility(View.VISIBLE);
                holder.btn_deny.setVisibility(View.GONE);
                holder.btn_accept.setVisibility(View.GONE);

                databaseReference.child(currentUser.getUid())
                        .child(friendRequestModel.getUserId())
                        .child(NodeNames.FRIEND_REQUEST_TYPE)
                        .setValue(null).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            databaseReference.child(friendRequestModel.getUserId())
                                    .child(currentUser.getUid())
                                    .child(NodeNames.FRIEND_REQUEST_TYPE)
                                    .setValue(null).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                    {
                                        Toast.makeText(context,R.string.delete_request_success
                                                , Toast.LENGTH_SHORT).show();
                                        holder.pbDecision.setVisibility(View.GONE);
                                        holder.btn_deny.setVisibility(View.VISIBLE);
                                        holder.btn_accept.setVisibility(View.VISIBLE);
                                    }else
                                    {
                                        Toast.makeText(context,context.getString(R.string.delete_request_failed
                                                ,task.getException()), Toast.LENGTH_SHORT).show();
                                        holder.pbDecision.setVisibility(View.GONE);
                                        holder.btn_deny.setVisibility(View.VISIBLE);
                                        holder.btn_accept.setVisibility(View.VISIBLE);
                                    }
                                }
                            });
                        }else
                        {
                            Toast.makeText(context,context.getString(R.string.delete_request_failed
                                    ,task.getException()), Toast.LENGTH_SHORT).show();
                            holder.pbDecision.setVisibility(View.GONE);
                            holder.btn_deny.setVisibility(View.VISIBLE);
                            holder.btn_accept.setVisibility(View.VISIBLE);

                        }
                    }
                });
            }
        });


    }

    private void handlingException(FriendRequestViewHolder holder, Exception exception) {
        Toast.makeText(context,context.getString(R.string.accept_request_failed
                ,exception), Toast.LENGTH_SHORT).show();
        holder.pbDecision.setVisibility(View.GONE);
        holder.btn_deny.setVisibility(View.VISIBLE);
        holder.btn_accept.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        Log.e("Request",String.valueOf(friendRequestModelList.size()));
        return friendRequestModelList.size();

    }
    public void  filterList(ArrayList<FriendRequestModel> filteredList)
    {
        friendRequestModelList = filteredList;
        notifyDataSetChanged();
    }

       @Override public int getItemViewType(int position) {        return position;}

    public class FriendRequestViewHolder extends RecyclerView.ViewHolder {

        TextView username;
        ImageView profileImage;
        Button btn_accept,btn_deny;
        ProgressBar pbDecision;

        public FriendRequestViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.tvUsername);
            profileImage = itemView.findViewById(R.id.profileImageView);
            btn_accept = itemView.findViewById(R.id.btn_accept);
            btn_deny = itemView.findViewById(R.id.btn_deny);
            pbDecision = itemView.findViewById(R.id.pbAcceptOrDeny);
        }
    }
}
