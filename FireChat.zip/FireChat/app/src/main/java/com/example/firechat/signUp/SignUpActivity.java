package com.example.firechat.signUp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Patterns;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.example.firechat.login.LoginActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

import static android.view.View.GONE;

public class SignUpActivity extends AppCompatActivity {

    private TextInputEditText etEmail , etName , etPassword , etConfirmPassword;
    private String email , name , password, confirmPassword;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private Uri localFileUri , ServerFileUri;
    private ImageView ivProfile;
    private StorageReference mStorageRef;
    private View progressBar;





    public void selectImage(View view)
    {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 101);
        }else
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},102);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 102)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, 101);
            }else
            {
                Toast.makeText(this, R.string.access_permission_required, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101)
        {
            if(resultCode == RESULT_OK)
            {
                localFileUri = data.getData();
                ivProfile.setImageURI(localFileUri);

            }
        }
    }


    private void updateNameAndPhoto()
    {   progressBar.setVisibility(View.VISIBLE);
        String strFileName = user.getUid() + ".jpg";
        final StorageReference fileStr = mStorageRef.child("images/" + strFileName);
        fileStr.putFile(localFileUri)
                .addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        progressBar.setVisibility(GONE);
                        if(task.isSuccessful())
                        {
                            fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    ServerFileUri = uri;
                                    UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                                            .setDisplayName(etName.getText().toString().trim())
                                            .setPhotoUri(ServerFileUri)
                                            .build();

                                    user.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                            if(task.isSuccessful())
                                            {
                                                String userID  = user.getUid();
                                                databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
                                                HashMap<String , String> hashMap = new HashMap<>();
                                                hashMap.put(NodeNames.NAME,etName.getText().toString().trim());
                                                hashMap.put(NodeNames.EMAIL,etEmail.getText().toString().trim());
                                                hashMap.put(NodeNames.ONLINE,"true");
                                                hashMap.put(NodeNames.PHOTO,ServerFileUri.getPath());
                                                progressBar.setVisibility(View.VISIBLE);
                                                databaseReference.child(userID).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        progressBar.setVisibility(GONE);
                                                        if(task.isSuccessful())
                                                        {
                                                            Toast.makeText(SignUpActivity.this, R.string.user_created_successfully, Toast.LENGTH_SHORT).show();
                                                            startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                                            finish();
                                                        }else
                                                        {
                                                            Toast.makeText(SignUpActivity.this, getString(R.string.signup_failed,task.getException()), Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });
                                            }else
                                            {
                                                Toast.makeText(SignUpActivity.this,getString(R.string.signup_failed,task.getException()) , Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    }
                });
    }

    private void updateOnlyName()
    {
        UserProfileChangeRequest request = new UserProfileChangeRequest.Builder()
                .setDisplayName(etName.getText().toString().trim())
                .build();
        progressBar.setVisibility(View.VISIBLE);

        user.updateProfile(request).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                progressBar.setVisibility(GONE);
                if(task.isSuccessful())
                {
                    String userID  = user.getUid();
                    databaseReference = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
                    HashMap<String , String> hashMap = new HashMap<>();
                    hashMap.put(NodeNames.NAME,etName.getText().toString().trim());
                    hashMap.put(NodeNames.EMAIL,etEmail.getText().toString().trim());
                    hashMap.put(NodeNames.ONLINE,"true");
                    hashMap.put(NodeNames.PHOTO,"");
                    progressBar.setVisibility(View.VISIBLE);
                    databaseReference.child(userID).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            progressBar.setVisibility(GONE);
                            if(task.isSuccessful())
                            {
                                Toast.makeText(SignUpActivity.this, R.string.user_created_successfully, Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                finish();
                            }else
                            {
                                Toast.makeText(SignUpActivity.this, getString(R.string.signup_failed,task.getException()), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }else
                {
                    Toast.makeText(SignUpActivity.this,getString(R.string.signup_failed,task.getException()) , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Window window = this.getWindow();

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorAccent));

        if(getSupportActionBar()!=null)
            getSupportActionBar().hide();

        progressBar = findViewById(R.id.progressBar);
        etEmail = findViewById(R.id.etEmail);
        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etOldPassword);
        etConfirmPassword = findViewById(R.id.etNewPassword);
        ivProfile = findViewById(R.id.profileImageView);
        mStorageRef = FirebaseStorage.getInstance().getReference();
    }
    public void SignUp(View view)
    {
        email = etEmail.getText().toString().trim();
        name = etName.getText().toString().trim();
        password = etPassword.getText().toString().trim();
        confirmPassword = etConfirmPassword.getText().toString().trim();


        if(name.equals(""))
        {
            etName.setError(getString(R.string.name_value));
        }
       else if(email.equals(""))
        {
            etEmail.setError(getString(R.string.email_value));
        }
        else if(password.equals(""))
        {
            etPassword.setError(getString(R.string.enter_password1));
        }
        else if(confirmPassword.equals(""))
        {
            etConfirmPassword.setError(getString(R.string.enter_confirm_password));
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            etEmail.setError(getString(R.string.email_incorrect));
        }
        else if(!confirmPassword.equals(password))
        {
            etConfirmPassword.setError(getString(R.string.confirm_password_incorrect));
        }
        else
        {
            progressBar.setVisibility(View.VISIBLE);
            FirebaseAuth auth = FirebaseAuth.getInstance();
            auth.createUserWithEmailAndPassword(email,password)
            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    progressBar.setVisibility(GONE);
                    if(task.isSuccessful())
                    {
                        user = FirebaseAuth.getInstance().getCurrentUser();
                        if(localFileUri!=null)
                            updateNameAndPhoto();
                        else
                            updateOnlyName();
                    }else
                    {
                        Toast.makeText(SignUpActivity.this,getString(R.string.signup_failed,task.getException()) , Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }
}