package com.example.firechat.Chats;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.firechat.Comman.Constants;
import com.example.firechat.Comman.Extras;
import com.example.firechat.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ChatListAdapter extends RecyclerView.Adapter<ChatListAdapter.ChatListViewHolder> {

   private Context context;
   private List<ChatListModel> chatListModelList;
    ArrayList<ChatListModel> filteredList;

    public ChatListAdapter(Context context, List<ChatListModel> chatListModelList) {
        this.context = context;
        this.chatListModelList = chatListModelList;

        filteredList = new ArrayList<>();
        filteredList.addAll(chatListModelList);
    }

    @NonNull
    @Override
    public ChatListAdapter.ChatListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.chat_layout,parent,false);
        return new ChatListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ChatListAdapter.ChatListViewHolder holder, int position) {
        final ChatListModel chatListModel = chatListModelList.get(position);
        holder.userName.setText(chatListModel.getUserName());

        StorageReference fileStr = FirebaseStorage.getInstance().getReference()
                .child(Constants.PROFILE_FOLDER+"/"+chatListModel.getUserId()+".jpg");
        fileStr.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Glide.with(context)
                        .load(uri)
                        .placeholder(R.drawable.default__better)
                        .error(R.drawable.default__better)
                        .into(holder.profileImage);
            }
        });
        holder.llChats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra(Extras.USER_KEY,chatListModel.getUserId());
                intent.putExtra(Extras.USER_NAME,chatListModel.getUserName());
                intent.putExtra(Extras.PHOTO_NAME,chatListModel.getPhotoName());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return chatListModelList.size();
    }

    public void  filterList(ArrayList<ChatListModel> filteredList)
    {
        chatListModelList = filteredList;
        notifyDataSetChanged();
    }


    @Override public int getItemViewType(int position) {        return position;}





    public class ChatListViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout llChats;
       private ImageView profileImage;
        private TextView userName;
        private TextView lastMessage;
        private TextView lastMessageTime;
        private TextView unreadCount;

        public ChatListViewHolder(@NonNull View itemView) {
            super(itemView);
            llChats  = itemView.findViewById(R.id.llChatList);
            profileImage = itemView.findViewById(R.id.profileImageView);
            userName = itemView.findViewById(R.id.tvUsername);
            lastMessage = itemView.findViewById(R.id.tvLastMessage);
            lastMessageTime = itemView.findViewById(R.id.tvLastMessageTime);
            unreadCount = itemView.findViewById(R.id.tvUnreadCount);
        }
    }
}
