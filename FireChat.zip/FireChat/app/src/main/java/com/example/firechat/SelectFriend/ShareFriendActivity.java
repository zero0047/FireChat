package com.example.firechat.SelectFriend;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.firechat.Comman.Extras;
import com.example.firechat.Comman.NodeNames;
import com.example.firechat.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class ShareFriendActivity extends AppCompatActivity {
    private RecyclerView rvSelectFriend;
    private List<SelectFriendModel> selectFriendModelList;
    private SelectFriendAdapter selectFriendAdapter;
    private View progressBar;

    private String message,messageId,messageType;

    private DatabaseReference databaseReferenceUser,databaseReferenceChat;
    private FirebaseUser currentUser;
    private ValueEventListener valueEventListener;

    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(getIntent().hasExtra(Extras.MESSAGE)){
            message = getIntent().getStringExtra(Extras.MESSAGE);
            messageId = getIntent().getStringExtra(Extras.MESSAGE_ID);
            messageType = getIntent().getStringExtra(Extras.MESSAGE_TYPE);
        }

        setContentView(R.layout.activity_share_friend);
        rvSelectFriend = findViewById(R.id.rvShareFriend);
        progressBar = findViewById(R.id.progressBar);
        etSearch = findViewById(R.id.etSearch);



        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rvSelectFriend.setLayoutManager(linearLayoutManager);
        selectFriendModelList = new ArrayList<>();
        selectFriendAdapter = new SelectFriendAdapter(this,selectFriendModelList);
        rvSelectFriend.setAdapter(selectFriendAdapter);

        progressBar.setVisibility(View.VISIBLE);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        databaseReferenceChat = FirebaseDatabase.getInstance().getReference().child(NodeNames.CHATS)
                .child(currentUser.getUid());
        databaseReferenceUser = FirebaseDatabase.getInstance().getReference().child(NodeNames.USERS);
        load();
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (!editable.toString().trim().matches(""))
                {
                    filter(editable.toString());
                }

            }
        });

    }
    private void load(){
        valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds: snapshot.getChildren()){
                    final String userId = ds.getKey();
                    databaseReferenceUser.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String userName = snapshot.child(NodeNames.NAME).getValue()!=null?
                                    snapshot.child(NodeNames.NAME).getValue().toString():"";
                            SelectFriendModel selectFriendModel = new SelectFriendModel(userId,userId+".jpg",userName);
                            selectFriendModelList.add(selectFriendModel);
                            selectFriendAdapter.notifyDataSetChanged();
                            progressBar.setVisibility(View.GONE);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(ShareFriendActivity.this,
                                    getString(R.string.failed_to_fetch_list,error.getMessage()), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ShareFriendActivity.this,
                        getString(R.string.failed_to_fetch_list,error.getMessage()), Toast.LENGTH_SHORT).show();
            }
        };
        databaseReferenceChat.addValueEventListener(valueEventListener);    
    }
    private void filter(String text) {
        if(text.equals(""))
        {

        }
        ArrayList<SelectFriendModel> filteredList = new ArrayList<>();

        for (SelectFriendModel item : selectFriendModelList)
        {
            if (item.getUserName().toLowerCase().contains(text.toLowerCase()))
            {
                filteredList.add(item);
            }
        }

        selectFriendAdapter.filterList(filteredList);
    }
    public void returnSelectedFriend(String userId , String userName, String photoName){
        databaseReferenceChat.removeEventListener(valueEventListener);
        Intent intent = new Intent();

        intent.putExtra(Extras.USER_KEY,userId);
        intent.putExtra(Extras.USER_NAME,userName);
        intent.putExtra(Extras.PHOTO_NAME,photoName);

        intent.putExtra(Extras.MESSAGE,message);
        intent.putExtra(Extras.MESSAGE_ID,messageId);
        intent.putExtra(Extras.MESSAGE_TYPE,messageType);
        setResult(Activity.RESULT_OK,intent);
        finish();
    }
}